CURRENT_ROOM = nil
CURRENT_ROOM_ADDRESS = "Lvl_Overworld"

TABS_MAPPING = 
{
    [""] = "Overworld",
    [""] = "East Forest"
}