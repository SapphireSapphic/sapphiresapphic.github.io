# Tunic Randomizer Tracker by SapphireSapphic and ScoutJD

Still a work in progress, but everything needed for basic package functionality is here. 
To install, please download the package as a zip file, and then put that zip file into Documents/Emotracker/packs
Extracting the file is not necessary, simply leave the zip as it is in the folder and the package should work just fine.
If you encounter any issues, please contact SapphireSapphic#8218 on discord.

Special thanks to SilentDestroyer for making the Tunic randomizer, and also for various insights that hepled make this package possible.
Shoutouts to Ekkosangen for noticing lots of little things that make the tracker better :)
